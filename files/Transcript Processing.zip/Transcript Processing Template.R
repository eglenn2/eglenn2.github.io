source("paragraph_transcript.R")

#Change the input filename and output filename accordingly
#Set the filepath where your transcripts are
#here can be a nifty package for working with filepaths 

input_filename <- "your transcript.txt"
output_filename <- "your transcript_processed.txt"
path <- "yourfilepath"
setwd(path)
#make sure your filepath ends with a slash
#make sure you substitute \ with \\ or use / slashes in the filepath


#There will be an error message if the speaker is missing that says 
#"Check row(s) N and check name". 
#You should add the name using a Speaker: text format.
paragraph_transcript(path, input_filename, output_filename)