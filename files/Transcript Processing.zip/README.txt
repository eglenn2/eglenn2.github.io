Oh look! Some documentation. 

Transcript Processing
Liz G
9/17/2020

These are just a few R scripts that can help you transform a transcript that is in the following format:
Line
Timestamp 00.00.00.000 --> 00.00.00.000
Name: Text

Into a paragraph style transcript that looks more like:

Speaker 1: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
Speaker 2: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Which, when copied into most word processors, should take the form of nice looking paragraphs. 

Files:
[1] paragraph_transcript.R
[2] Load Dependencies.R
[3] Transcript Processing Template.R
[4] Transcript Processing Template.Rmd
[5] Transcript-Processing-Template.html


[1]
paragraph_transcript.R

Function that does exactly what was said above.

paragraph_transcript(file_path, input_file, output_file)

The function has three inputs: file_path, input_file, output_file

file_path = the path where the .txt transcript is, and where the output .txt will go
input_file = what the .txt file is called
output_file = what you want the processed file to be called

All of these inputs are considered character strings in R, and thus, should be within quotation marks, ""
Packages needed for this function are called within the function

[2]
Install Dependencies.R

This script includes code to install the packages required for the function to run

[3] Transcript Processing Template.R

This script includes code to run the function. The package dependencies must be installed

[4] Transcript Processing Template.Rmd

This R markdown file includes code from [2], and [3], which can be run within the .Rmd file, and also more detailed explanation

[5]

This .html file is an .html version of the .Rmd file above