paragraph_transcript <- function(file_path, input_file, output_file)
{#Loading Dependencies
  library(tidyverse)
  library(readr)
  library(rio)
  
  
  #Reading in file
  text_raw <- read_delim((paste0(file_path, input_file)), delim = "\n")

  
  #Checking to make sure every line includes a speaker; gives error message and prints
  #line numbers if not
  three_rows <-  seq(3, nrow(text_raw), by = 3)
  speaker_check <- text_raw
  speaker_check <- speaker_check %>% mutate(row = row_number()) %>%
    filter(row %in% three_rows) %>% 
    select(WEBVTT) %>% 
    mutate(name = str_detect(WEBVTT, ":"), row = row_number()) %>% 
    filter(name == FALSE)
  
  message <- ifelse(nrow(speaker_check) > 0, paste0("Check row(s) ", paste(speaker_check$row, collapse = ", ")," and add name"), "No errors")
  print(message)
  if(nrow(speaker_check) > 0) stop(message)
 
  #Separating time-stamps, line numbers, text, and speaker into 4 vectors. 
  #Regex for timestamp = "([0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3} --> [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3})"
  #Regex for line number = "(^[0-9]{1,3}$)"
  #Separator for speaker and text = ":"
   
  text_columns <- text_raw %>% 
    extract(WEBVTT, c("time"), regex = "([0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3} --> [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3})", remove = FALSE) %>% 
    mutate(og_column = str_replace(WEBVTT, "([0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3} --> [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3})", NA_character_)) %>% 
    extract(og_column, c("line"), regex = "(^[0-9]{1,3}$)", remove = FALSE) %>% 
    mutate(og_column = str_replace(og_column,  "(^[0-9]{1,3}$)", NA_character_)) %>%
    separate(og_column, c("name", "text"), sep = ":", remove = FALSE)
  
  #creating seperate vectors
  line_column <- text_columns %>% select(line) %>% filter(str_detect(line, "([0-9]{1,3})") == TRUE)
  name_column <- text_columns %>% select(name) %>% filter(str_detect(name, "\\w") == TRUE)
  text_column <- text_columns %>% select(text) %>% filter(str_detect(text, "\\w") == TRUE)
  time_column <- text_columns %>% select(time) %>% filter(str_detect(time, "([0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3} --> [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3})") == TRUE)
  
  
  #creating vector of lines where the speaker changes
  full_data <- cbind(line_column, name_column, text_column, time_column)
  change <- which(full_data$name != lag(full_data$name))
  speaker_change <- vector(mode = "numeric", length = nrow(full_data))
  
  #creating vector that counts speaker changes (and populates by line)
  count <- 0
  for (i in 1:length(speaker_change)) {
    for(j in change) {
      x <- ifelse(i == j, 1, 0)
      count <- x + count
    }
    speaker_change[i] <- count
  }
  
  #appending vector
  full_data <- cbind(full_data, speaker_change)
  #creating a variable of the speaker paragraph from name and change vector
  #some word cleaning to make sure isn't capitilization every new line
  full_data <- full_data %>% 
    unite("paragraph", name, speaker_change, sep = "_", remove = FALSE) %>% 
    group_by(paragraph) %>% 
    mutate(full_text = paste0(text, collapse = "")) %>% 
    mutate(full_text = str_to_sentence(full_text)) %>% 
    mutate(full_text = str_replace_all(full_text, " i ", " I ")) %>% 
    mutate(full_text = str_replace_all(full_text, " i'", " I'")) 
  
  change <- append(1,change)
  
  #condensing into paragraphs
  condensed_data <- full_data %>% filter(line %in% change) %>% select(name, full_text, paragraph) %>% unite("full_text", name, full_text, sep= ":")
  
  #data export
  export_data <- as.data.frame(condensed_data$full_text)
  
  export(export_data, paste0(file_path, output_file))
  
  #function written by Liz Glenn, eglenn2@uoregon.edu
}